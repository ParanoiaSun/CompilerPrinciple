CREATE VIEW `article_writer` AS
  (SELECT
     `a`.`article_id`    AS `article_id`,
     `a`.`writer_id`     AS `writer_id`,
     `a`.`article_title` AS `article_title`,
     `a`.`content`       AS `content`,
     `a`.`create_time`   AS `create_time`,
     `t1`.`total`        AS `total`,
     `t2`.`writer_name`  AS `writer_name`,
     `t2`.`writer_email` AS `writer_email`
   FROM ((`sql_assignment1_3`.`platform_article` `a`
     JOIN (SELECT
             `d`.`article_id`        AS `article_id`,
             sum(`d`.`deal_payment`) AS `total`
           FROM `sql_assignment1_3`.`platform_deal` `d`
           GROUP BY `d`.`article_id`) `t1`) JOIN (SELECT
                                                    `w`.`writer_id`    AS `writer_id`,
                                                    `w`.`writer_name`  AS `writer_name`,
                                                    `w`.`writer_email` AS `writer_email`
                                                  FROM `sql_assignment1_3`.`platform_writer` `w`) `t2`)
   WHERE ((`t1`.`article_id` = `a`.`article_id`) AND (`t2`.`writer_id` = `a`.`writer_id`)))