CREATE TRIGGER `modifywritername`
BEFORE INSERT ON `platform_writer`
FOR EACH ROW
  BEGIN
    DECLARE name VARCHAR(30);
    SET name=concat('w_', new.writer_name);
    SET new.writer_name=name;
  END